// TSC AI PHOTO - JavaScript kecil, tanpa dependensi.
// Tanpa JS, situs tetap bisa dipakai: semua kartu tampil dan link download tetap bekerja.
(function () {
  'use strict';

  // ---------- pesan galat ----------
  var toastEl = null;
  var toastTimer = null;
  function showToast(message) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.className = 'toast';
      toastEl.setAttribute('role', 'alert');
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = message;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 9000);
  }

  // ---------- gambar preview gagal dimuat ----------
  function markBroken(img) {
    var holder = img.closest('.card-media, .viewer');
    if (!holder) return;
    holder.classList.add('is-broken');
    var note = holder.querySelector('.media-fallback');
    if (note) note.hidden = false;
  }
  document.addEventListener('error', function (e) {
    if (e.target && e.target.tagName === 'IMG') markBroken(e.target);
  }, true);
  document.querySelectorAll('img').forEach(function (img) {
    if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) markBroken(img);
  });

  // ---------- perlindungan gambar wallpaper ----------
  // Mengurangi menyimpan lewat long-press, menu klik kanan, dan menyeret gambar.
  // Hanya berlaku di area gambar wallpaper (kartu, pratinjau detail, panel Home).
  // Bukan jaminan: screenshot, developer tools, dan alamat file tetap bisa dipakai.
  // Tombol Download Wallpaper ada di luar area ini, jadi tidak terpengaruh.
  var PROTECTED = '.card-media, .viewer, .glass-inner';
  function inProtected(target) {
    return !!(target && target.closest && target.closest(PROTECTED));
  }
  document.addEventListener('contextmenu', function (e) {
    if (inProtected(e.target)) e.preventDefault();
  });
  document.addEventListener('dragstart', function (e) {
    if (inProtected(e.target)) e.preventDefault();
  });

  // ---------- download file original ----------
  // Cek dulu (HEAD, tanpa mengunduh isi file) bahwa file original ada dan ukurannya
  // sesuai katalog. Kalau gagal, tampilkan pesan. Preview TIDAK PERNAH dipakai sebagai pengganti.
  document.addEventListener('click', function (e) {
    var link = e.target.closest && e.target.closest('a[data-original]');
    if (!link || e.defaultPrevented || e.button > 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    if (!window.fetch) return; // browser lama: biarkan link bekerja normal
    e.preventDefault();

    var href = link.getAttribute('href');
    var expected = parseInt(link.getAttribute('data-bytes'), 10);
    if (link.classList.contains('is-busy')) return; // sedang memeriksa, abaikan klik ganda
    link.classList.add('is-busy');
    link.setAttribute('aria-busy', 'true');
    function done() {
      link.classList.remove('is-busy');
      link.removeAttribute('aria-busy');
    }

    fetch(href, { method: 'HEAD', cache: 'no-store' })
      .then(function (res) {
        if (!res.ok) {
          throw new Error('The original file could not be found (error ' + res.status + '). It has not been replaced with a preview. Please try again later.');
        }
        var type = res.headers.get('content-type') || '';
        if (type && type.indexOf('image/') !== 0 && type.indexOf('octet-stream') === -1) {
          throw new Error('The server returned something other than the original image. The download was stopped.');
        }
        var length = parseInt(res.headers.get('content-length'), 10);
        if (expected && length && length !== expected) {
          throw new Error('The file on the server does not match the original size (' + length + ' bytes, expected ' + expected + '). The download was stopped.');
        }
        var a = document.createElement('a');
        a.href = href;
        a.download = link.getAttribute('download') || '';
        a.rel = 'noopener';
        document.body.appendChild(a);
        a.click();
        a.remove();
        done();
      })
      .catch(function (err) {
        done();
        var offline = err instanceof TypeError;
        showToast(offline
          ? 'Could not reach the server to download the original file. Check your connection and try again.'
          : err.message);
      });
  });

  // ---------- pemilih versi wallpaper (hanya ada jika wallpaper punya variasi) ----------
  // Data tiap versi ada di <script id="versions-data">. Memilih versi hanya mengganti preview,
  // metadata, dan tujuan tombol download. File original tidak diminta sebelum tombol ditekan.
  (function initVersions() {
    var dataEl = document.getElementById('versions-data');
    var picker = document.querySelector('[data-versions]');
    if (!dataEl || !picker) return;
    var versions;
    try { versions = JSON.parse(dataEl.textContent); } catch (err) { return; }
    var byId = {};
    versions.forEach(function (v) { byId[v.id] = v; });

    var viewer = document.querySelector('.viewer');
    var img = viewer && viewer.querySelector('img');
    var fallback = viewer && viewer.querySelector('.media-fallback');
    var dl = document.querySelector('.detail-actions a[data-original]');
    var note = document.querySelector('[data-note]');
    var hashEl = document.querySelector('[data-hash]');
    var verifyInput = document.querySelector('input[data-verify]');
    var verifyResult = document.querySelector('.verify-result');
    if (!img || !dl) return;

    function setSpec(name, value) {
      var el = document.querySelector('[data-spec="' + name + '"]');
      if (el) el.textContent = value;
    }

    function apply(id, updateUrl) {
      var v = byId[id];
      if (!v) return;
      // preview (display only)
      if (viewer) viewer.classList.remove('is-broken');
      if (fallback) fallback.hidden = true;
      if (img.getAttribute('src') !== v.large) {
        if (viewer) viewer.classList.add('is-loading');
        img.onload = img.onerror = function () { if (viewer) viewer.classList.remove('is-loading'); };
        img.setAttribute('width', v.largeW);
        img.setAttribute('height', v.largeH);
        img.alt = v.alt;
        img.setAttribute('src', v.large);
      }
      // metadata dari file asli versi ini
      setSpec('resolution', v.resolution);
      setSpec('ratio', v.ratio);
      setSpec('format', v.format);
      setSpec('size', v.size);
      if (note) note.textContent = 'This page shows a smaller preview. The download is the original ' + v.format + ' file, ' + v.resolution + ', exactly as uploaded.';
      // tombol download -> file original versi ini
      dl.setAttribute('href', v.download);
      dl.setAttribute('download', v.downloadName);
      dl.setAttribute('data-bytes', v.bytes);
      // alat verifikasi ikut berpindah ke versi ini
      if (hashEl) hashEl.textContent = v.sha256;
      if (verifyInput) {
        verifyInput.setAttribute('data-sha', v.sha256);
        verifyInput.setAttribute('data-bytes', v.bytes);
        verifyInput.setAttribute('data-width', v.width);
        verifyInput.setAttribute('data-height', v.height);
        verifyInput.value = '';
      }
      if (verifyResult) { verifyResult.textContent = ''; verifyResult.className = 'verify-result'; }
      // alamat bisa dibagikan: ?v=modern-laptop
      if (updateUrl && window.history && history.replaceState) {
        var url = new URL(window.location.href);
        if (id === versions[0].id) url.searchParams.delete('v'); else url.searchParams.set('v', id);
        history.replaceState(null, '', url.pathname + url.search + url.hash);
      }
    }

    picker.addEventListener('change', function (e) {
      if (e.target && e.target.name === 'version') apply(e.target.value, true);
    });

    var wanted = new URLSearchParams(window.location.search).get('v');
    if (wanted && byId[wanted] && wanted !== versions[0].id) {
      var radio = picker.querySelector('input[value="' + wanted + '"]');
      if (radio) { radio.checked = true; apply(wanted, false); }
    }
  })();

  // ---------- verifikasi file hasil download (SHA-256 di perangkat) ----------
  document.querySelectorAll('input[data-verify]').forEach(function (input) {
    var result = input.closest('.verify').querySelector('.verify-result');
    function say(text, ok) {
      result.textContent = text;
      result.className = 'verify-result ' + (ok ? 'ok' : 'bad');
    }
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      if (!file) return;
      if (!(window.crypto && window.crypto.subtle)) {
        say('Verification needs a secure page (https). Open the site over https and try again.', false);
        return;
      }
      result.className = 'verify-result';
      result.textContent = 'Checking...';
      var expectedHash = input.getAttribute('data-sha');
      var expectedBytes = parseInt(input.getAttribute('data-bytes'), 10);

      file.arrayBuffer()
        .then(function (buf) { return crypto.subtle.digest('SHA-256', buf); })
        .then(function (digest) {
          var hex = Array.prototype.map.call(new Uint8Array(digest), function (b) {
            return b.toString(16).padStart(2, '0');
          }).join('');
          var sizeOk = file.size === expectedBytes;
          if (hex === expectedHash && sizeOk) {
            say('Match. This file is byte-for-byte identical to the original (' + file.size + ' bytes).', true);
          } else {
            say('No match. This file differs from the original' + (sizeOk ? '.' : ' (' + file.size + ' bytes, expected ' + expectedBytes + ').') +
              ' Some apps or messengers recompress images. Download it again directly from this page.', false);
          }
        })
        .catch(function () { say('This file could not be read. Please try again.', false); });
    });
  });

  // ---------- Gallery: pencarian, filter, "show more" ----------
  var grid = document.getElementById('grid');
  var tools = document.querySelector('[data-tools]');
  if (!grid) return;

  var cards = Array.prototype.slice.call(grid.querySelectorAll('.card'));
  var pageSize = parseInt(grid.getAttribute('data-page-size'), 10) || 12;
  var shownLimit = pageSize;
  var query = '';
  var filters = { category: '', character: '' };

  var statusEl = document.getElementById('gallery-status');
  var emptyEl = document.getElementById('empty');
  var moreBtn = document.getElementById('more');

  function render() {
    var matching = cards.filter(function (card) {
      if (filters.category && card.getAttribute('data-category') !== filters.category) return false;
      if (filters.character && card.getAttribute('data-character') !== filters.character) return false;
      if (query && card.getAttribute('data-search').indexOf(query) === -1) return false;
      return true;
    });
    var visible = matching.slice(0, shownLimit);
    cards.forEach(function (card) { card.hidden = visible.indexOf(card) === -1; });

    if (statusEl) {
      statusEl.textContent = matching.length === cards.length && visible.length === cards.length
        ? cards.length + (cards.length === 1 ? ' wallpaper' : ' wallpapers')
        : 'Showing ' + visible.length + ' of ' + matching.length + (matching.length === 1 ? ' wallpaper' : ' wallpapers');
    }
    if (emptyEl) emptyEl.hidden = matching.length !== 0 || cards.length === 0;
    if (moreBtn) moreBtn.hidden = visible.length >= matching.length;
  }

  if (tools) {
    var input = document.getElementById('q');
    if (input) {
      input.addEventListener('input', function () {
        query = input.value.trim().toLowerCase();
        shownLimit = pageSize;
        render();
      });
    }
    tools.addEventListener('click', function (e) {
      var chip = e.target.closest('.chip');
      if (!chip) return;
      var group = chip.getAttribute('data-group');
      filters[group] = chip.getAttribute('data-value');
      tools.querySelectorAll('.chip[data-group="' + group + '"]').forEach(function (c) {
        var on = c === chip;
        c.classList.toggle('is-active', on);
        c.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      shownLimit = pageSize;
      render();
    });
  }

  if (moreBtn) {
    moreBtn.addEventListener('click', function () {
      shownLimit += pageSize;
      render();
    });
  }

  var reset = document.getElementById('reset');
  if (reset) {
    reset.addEventListener('click', function () {
      query = '';
      filters = { category: '', character: '' };
      shownLimit = pageSize;
      var input = document.getElementById('q');
      if (input) input.value = '';
      document.querySelectorAll('.chip').forEach(function (c) {
        var on = c.getAttribute('data-value') === '';
        c.classList.toggle('is-active', on);
        c.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      render();
    });
  }

  render();
})();
