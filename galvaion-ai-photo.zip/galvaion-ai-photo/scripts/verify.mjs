// Memeriksa bahwa file yang disajikan identik dengan file original.
//
//   npm run verify                         -> cek hasil build lokal (dist/) terhadap content/originals/
//   npm run verify -- https://situs.pages.dev  -> unduh tiap file original dari situs yang sudah online,
//                                              lalu bandingkan SHA-256, ukuran, dan dimensi dengan katalog
//
// Exit code 1 jika ada yang tidak cocok.

import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(ROOT, 'dist');
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

const target = process.argv[2] ? process.argv[2].replace(/\/+$/, '') : '';
let failed = 0;
const pass = (name, msg) => console.log(`  PASS  ${name}  ${msg}`);
const fail = (name, msg) => {
  failed++;
  console.log(`  FAIL  ${name}  ${msg}`);
};

let catalog;
try {
  catalog = JSON.parse(await fs.readFile(path.join(DIST, 'data', 'wallpapers.json'), 'utf8'));
} catch {
  console.error('dist/data/wallpapers.json tidak ditemukan. Jalankan "npm run build" dulu.');
  process.exit(1);
}

console.log(`\nMemeriksa ${catalog.length} wallpaper${target ? ` di ${target}` : ' (build lokal)'}\n`);

const MAX_PAGES_FILE = 25 * 1024 * 1024; // batas Cloudflare Pages per file
const exactExists = async (baseDir, rel) => {
  let dir = baseDir;
  for (const part of path.normalize(rel).split(path.sep).filter(Boolean)) {
    const names = await fs.readdir(dir).catch(() => []);
    if (!names.includes(part)) return false; // juga menangkap beda huruf besar/kecil
    dir = path.join(dir, part);
  }
  return true;
};

let config = {};
try {
  config = JSON.parse(await fs.readFile(path.join(ROOT, 'site.config.json'), 'utf8'));
} catch {
  /* tanpa konfigurasi: pemeriksaan rasio kategori dilewati */
}
const variantTypes = config.variantTypes || {};

// Setiap wallpaper punya versi utama (field "file") dan, jika ada, variasi ukuran.
const targets = [];
for (const wp of catalog) {
  targets.push({ ...wp, versionId: 'original' });
  for (const v of wp.variants || []) targets.push({ ...v, versionId: v.id });
}
console.log(`Total ${targets.length} file original (termasuk variasi ukuran).\n`);

for (const wp of targets) {
  const name = wp.downloadName;
  try {
    const problemsPre = [];
    // path dan huruf besar/kecil nama file harus persis (Cloudflare membedakan)
    if (!(await exactExists(path.join(ROOT, 'content', 'originals'), wp.sourceFile))) {
      problemsPre.push(`content/originals/${wp.sourceFile} tidak ditemukan dengan huruf besar/kecil yang persis`);
    }
    if (!target && !(await exactExists(path.join(DIST, 'original'), path.basename(wp.original)))) {
      problemsPre.push(`${wp.original} tidak ada di dist/ (atau beda huruf besar/kecil)`);
    }
    // preview versi ini harus ada (dipakai pemilih versi), tapi bukan file download
    const previewPath = wp.previewLarge;
    if (!target && previewPath && !(await exactExists(path.join(DIST, 'previews'), path.basename(previewPath)))) {
      problemsPre.push(`preview ${previewPath} tidak ada di dist/`);
    }
    if (wp.versionId !== 'original') {
      const type = variantTypes[wp.versionId];
      if (type) {
        const [rw, rh] = type.ratio;
        if (Math.abs(wp.width / wp.height - rw / rh) / (rw / rh) > 0.02) {
          problemsPre.push(`rasio ${wp.width}x${wp.height} tidak sesuai kategori "${type.label}" (${rw}:${rh})`);
        }
      } else if (Object.keys(variantTypes).length) {
        problemsPre.push(`id varian "${wp.versionId}" tidak ada di site.config.json > variantTypes`);
      }
    }
    if (wp.bytes > MAX_PAGES_FILE) problemsPre.push(`ukuran ${wp.bytes} B melebihi batas Cloudflare Pages 25 MiB`);
    if (problemsPre.length) {
      fail(name, problemsPre.join('; '));
      continue;
    }
    const source = await fs.readFile(path.join(ROOT, 'content', 'originals', wp.sourceFile));
    let served;
    if (target) {
      const res = await fetch(target + wp.original);
      if (!res.ok) {
        fail(name, `server membalas ${res.status}`);
        continue;
      }
      served = Buffer.from(await res.arrayBuffer());
    } else {
      served = await fs.readFile(path.join(DIST, wp.original.replace(/^\//, '')));
    }

    const meta = await sharp(served, { failOn: 'none' }).metadata();
    const w = meta.orientation && meta.orientation >= 5 ? meta.height : meta.width;
    const h = meta.orientation && meta.orientation >= 5 ? meta.width : meta.height;
    const problems = [];
    if (sha(served) !== sha(source)) problems.push('isi file berbeda dari content/originals');
    if (sha(served) !== wp.sha256) problems.push('checksum berbeda dari katalog');
    if (served.length !== wp.bytes) problems.push(`ukuran ${served.length} B, katalog ${wp.bytes} B`);
    if (w !== wp.width || h !== wp.height) problems.push(`dimensi ${w}x${h}, katalog ${wp.width}x${wp.height}`);
    if (problems.length) fail(name, problems.join('; '));
    else pass(name, `[${wp.versionId}] ${wp.width}x${wp.height} ${wp.format}, ${wp.bytes} B, sha256 ${wp.sha256.slice(0, 12)}...`);
  } catch (err) {
    fail(name, err.message);
  }
}

// Tidak boleh ada dua versi dengan isi file yang sama dalam satu wallpaper
for (const wp of catalog) {
  const seen = new Map([[wp.sha256, 'original']]);
  for (const v of wp.variants || []) {
    if (seen.has(v.sha256)) fail(wp.slug, `versi "${v.id}" duplikat dari "${seen.get(v.sha256)}" (isi file sama)`);
    seen.set(v.sha256, v.id);
  }
}

// File di content/originals/ yang tidak dipakai oleh wallpaper atau variasi mana pun (hanya peringatan)
const used = new Set();
for (const wp of catalog) {
  used.add(path.normalize(wp.sourceFile));
  for (const v of wp.variants || []) used.add(path.normalize(v.sourceFile));
}
const walk = async (dir) => {
  const out = [];
  for (const e of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...(await walk(full)));
    else out.push(full);
  }
  return out;
};
const orphans = (await walk(path.join(ROOT, 'content', 'originals')))
  .map((f) => path.relative(path.join(ROOT, 'content', 'originals'), f))
  .filter((f) => !used.has(path.normalize(f)) && !f.startsWith('.'));
if (orphans.length) {
  console.log(`\n  CATATAN  ${orphans.length} file di content/originals/ belum dipakai di wallpapers.json: ${orphans.join(', ')}`);
}

// Batas Cloudflare Pages: 25 MiB per file, untuk SEMUA file yang akan di-deploy
const tooBig = [];
for (const f of await walk(DIST)) {
  const size = (await fs.stat(f)).size;
  if (size > MAX_PAGES_FILE) tooBig.push(`${path.relative(DIST, f)} (${(size / 1048576).toFixed(1)} MiB)`);
}
if (tooBig.length) fail('batas-25MiB', `file melebihi 25 MiB: ${tooBig.join(', ')}`);
else pass('batas-25MiB', 'semua file di dist/ di bawah 25 MiB');

console.log(failed ? `\n${failed} pemeriksaan GAGAL.\n` : '\nSemua file identik dengan original.\n');
process.exit(failed ? 1 : 0);
