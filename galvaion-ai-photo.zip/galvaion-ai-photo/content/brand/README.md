# Logo GALVAION

File di folder ini adalah **logo asli (hitam, latar transparan)**. Jangan diedit, diwarnai ulang, atau diganti isinya.

| File | Isi |
|---|---|
| `galvaion-symbol-original.png` | simbol saja (dipakai untuk favicon, ikon browser, dan branding ringkas di header) |
| `galvaion-full-original.png` | logo penuh dengan tulisan GALVAION vertikal (dipakai di area brand footer) |

Saat `npm run build`, skrip membuat turunannya otomatis di `dist/logo/`:

- varian **putih** untuk latar gelap (inversi warna saja; bentuk, proporsi, dan transparansi tidak berubah),
- varian **hitam** untuk latar terang dan keperluan lain,
- ukuran siap pakai (1x, 2x, 3x) agar tetap tajam di layar HP,
- favicon dan ikon layar utama.

Tepi kosong (transparan) di sekeliling logo dipangkas supaya ukuran di halaman tepat. Isi logo dan jarak antar elemennya tidak diubah.

Untuk mengganti logo di masa depan, timpa dua file di atas dengan nama yang sama (hitam, latar transparan), lalu build ulang.
