# TSC AI PHOTO

Galeri wallpaper AI bertema The Spike Cross (dan siap diperluas ke karakter, game, atau tema lain).
Website statis (HTML/CSS/JS), ringan, mobile-first, siap di-host di Cloudflare Pages.

File yang didownload pengunjung adalah **file original yang kamu upload**, disalin byte-per-byte
(tanpa resize, crop, kompresi ulang, atau konversi format).

Laporan pengujian ada di [`TESTING.md`](TESTING.md).

---

## 1. Fitur

- **Home:** hero, panel gambar kaca (glassmorphism) milikmu sendiri, Featured wallpapers, Recently added.
- **Gallery:** grid responsif, pencarian, filter kategori dan karakter, tombol "Show more" (lazy loading), seluruh kartu bisa diklik.
- **Detail wallpaper:** `/wallpaper/<slug>` dengan preview besar tanpa crop, metadata dari file asli, tombol **Download Wallpaper** (hanya ada di halaman ini), kredit, dan alat verifikasi hasil download. Wallpaper pilihan bisa punya **variasi ukuran** (HP, tablet, laptop, desktop) yang dipilih pengunjung lewat pemilih versi.
- **About:** tujuan situs, cara kerja kredit, disclaimer non-afiliasi.
- **404:** halaman khusus dengan link berguna.
- **Navigasi responsif:** bottom bar di mobile portrait, sidebar vertikal di kiri untuk mobile landscape, tablet, dan desktop. Satu komponen, ikon + label, indikator tab aktif, aman untuk notch/safe area.
- **Desain dark editorial:** latar hitam pekat, aksen merah marun yang dipakai terbatas, judul uppercase condensed dengan letter-spacing lebar, label kecil bergaya `[ SISTEM ]`, garis tipis merah redup. Semua warna dan font ada di variabel CSS.
- **Download hanya di halaman detail:** kartu galeri dan Home hanya untuk memilih wallpaper, tanpa tombol download.
- **Perlindungan gambar ringan:** gambar wallpaper tidak bisa diseret, dipilih, atau dibuka menu klik-kanan/long-press-nya (area gambar saja). Ini hanya menghambat, bukan jaminan (lihat bagian 8).
- **Glow teks selektif:** hanya pada judul tertentu, bisa diatur lewat variabel CSS.
- **SEO:** title dan description per halaman, Open Graph, favicon, canonical, sitemap, robots.txt (sitemap dan URL absolut aktif setelah `siteUrl` diisi).

## 2. Struktur proyek

```
tsc-ai-photo/
├── content/
│   ├── wallpapers.json       KATALOG wallpaper (edit di sini)
│   ├── originals/            FILE ORIGINAL wallpaper, termasuk file tiap variasi ukuran (jangan diubah/dikompres)
│   └── home-panel/           gambar untuk panel kaca di Home
├── site.config.json          pengaturan situs: domain, TikTok/YouTube, panel Home, kredit, disclaimer, kategori variasi (variantTypes)
├── scripts/
│   ├── build.mjs             membaca file asli, membuat preview, halaman, sitemap; menyalin original + cek checksum
│   ├── verify.mjs            memeriksa semua file original (utama + variasi), nama file, rasio, batas 25 MiB
│   └── serve.mjs             server lokal untuk uji coba
├── src/
│   ├── pages/                isi halaman Home, Gallery, About, 404
│   ├── templates/            layout (navbar/footer) dan halaman detail wallpaper
│   └── static/               CSS, JS, favicon, _headers (aturan header Cloudflare)
├── package.json
└── dist/                     HASIL BUILD (dibuat otomatis, tidak masuk Git)
```

Isi `dist/` (situs yang tayang):

| Folder di `dist/` | Isi |
|---|---|
| `original/` | **file original**, nama rapi, dipakai tombol Download Wallpaper |
| `previews/` | preview kecil WebP (hanya untuk tampilan) |
| `og/` | gambar untuk pratinjau link di media sosial |
| `home-panel/` | salinan tampilan gambar panel Home |
| `data/wallpapers.json` | katalog publik berisi metadata + checksum SHA-256 |

## 3. Menambah wallpaper baru

Kamu cukup menambah **satu file gambar** dan **satu blok teks**. Resolusi, aspect ratio, ukuran file, dan format
**dibaca otomatis dari file asli** saat build. Jangan diisi manual.

1. **Folder file original:** `content/originals/`. Nama file bebas, contoh `isabel-neon.png`.
2. **Folder preview:** tidak perlu diisi. Preview dibuat otomatis ke `dist/previews/` saat build.
3. **Tambah entri** di `content/wallpapers.json` (jangan lupa koma di antara entri):

```json
{
  "title": "Neon Rain",
  "character": "Isabel",
  "file": "isabel-neon.png",
  "category": "Cyber",
  "tags": ["neon", "rain", "phone"],
  "featured": true,
  "artwork": "ai-generated",
  "description": "Isabel di tengah hujan neon.",
  "credit": "",
  "date": "2026-10-10"
}
```

| Field | Wajib | Keterangan |
|---|---|---|
| `title`, `character`, `file` | ya | `file` = nama file di `content/originals/` (huruf besar/kecil harus sama persis) |
| `category`, `tags` | tidak | dipakai untuk filter dan pencarian |
| `featured` | tidak | `true` = tampil di "Featured wallpapers" di Home |
| `artwork` | tidak | `ai-generated` (default), `fan-art`, atau `original`. Daftarnya ada di `artworkTypes` di `site.config.json` |
| `description`, `credit`, `date` | tidak | `date` format `YYYY-MM-DD`. Jika kosong dipakai tanggal file |
| `number` | tidak | nomor koleksi di label `NO. 003`. Otomatis dari urutan tanggal (terlama = 001). Isi untuk mengunci nomor |
| `slug` | tidak | otomatis dari karakter + judul (`isabel-neon-rain`). Isi untuk URL kustom |
| `variants` | tidak | variasi ukuran opsional, lihat bagian "Variasi ukuran" di bawah. Tanpa field ini wallpaper berperilaku seperti biasa |

4. **Metadata akurat:** otomatis. Hasilnya bisa dilihat di `dist/data/wallpapers.json` (resolusi, rasio, ukuran, format, SHA-256).
5. **Slug dan URL:** dibuat dari karakter + judul. Contoh di atas menjadi `/wallpaper/isabel-neon-rain`. Slug harus unik. Kalau bentrok, build berhenti dengan pesan jelas.
6. **Nama file download:** otomatis `TSC-Isabel-Neon-Rain-1080x2340.png` (resolusi diambil dari file asli).
7. **Verifikasi hasil download:** lihat bagian 8.
8. **Uji sebelum publish:** lihat alur Android di bawah, atau bagian 6 (komputer).
9. **Publish:** commit ke GitHub. Cloudflare Pages membangun dan menayangkan otomatis (bagian 5).

### Variasi ukuran (opsional, hanya untuk wallpaper pilihan)

Pengunjung bisa memilih versi wallpaper sesuai perangkat. Variasi **tidak dibuat otomatis** oleh situs:
kamu membuatnya dengan alat pengolah gambar sendiri, menyimpannya sebagai **file terpisah**, lalu mendaftarkannya.
Wallpaper yang tidak punya variasi tetap tampil dan berfungsi persis seperti sebelumnya.

Lima kelompok rasio yang didukung (id dipakai di `wallpapers.json`):

| id | Label di situs | Rasio | Contoh resolusi |
|---|---|---|---|
| `mobile` | Mobile | 9:16 | 1080 × 1920 |
| `tablet-portrait` | Tablet Portrait | 3:4 | 1200 × 1600 |
| `tablet-landscape` | Tablet Landscape | 4:3 | 1600 × 1200 |
| `modern-laptop` | Modern Laptop | 16:10 | 1920 × 1200 |
| `desktop-standard-laptop` | Desktop & Standard Laptop | 16:9 | 1920 × 1080 |

Catatan: ini lima kelompok rasio unik (kategori "Desktop & Standard Laptop" memakai 16:9). Resolusi di tabel hanya contoh.
Metadata mengikuti file sebenarnya. Ultrawide 21:9 dan 32:9 tidak ada di implementasi ini.

**Cara menambah variasi:**

1. Pilih wallpaper yang layak mendapat variasi.
2. Buat versi dengan rasio yang sesuai memakai alat eksternal (aplikasi edit foto, dll). Jangan memakai gambar yang sama untuk beberapa kategori.
3. Simpan tiap versi sebagai file terpisah di `content/originals/`, misalnya `isabel-neon-mobile.png`.
4. Tambahkan blok `variants` di entri wallpaper itu. Cantumkan **hanya** versi yang filenya sudah ada:

```json
{
  "title": "Neon Rain",
  "character": "Isabel",
  "file": "isabel-neon.png",
  "variants": {
    "mobile": { "file": "isabel-neon-mobile.png" },
    "desktop-standard-laptop": { "file": "isabel-neon-desktop.png" }
  }
}
```

5. Commit. Build dan deploy berjalan seperti biasa (bagian 5).

Yang terjadi di situs:

- Halaman detail menampilkan "Choose a version" berisi **Original** (file utama dari `file`) ditambah **hanya** versi yang kamu daftarkan. Versi yang tidak ada tidak muncul.
- Memilih versi mengganti preview, resolusi, rasio, format, ukuran file, dan tombol Download Wallpaper ke file original versi itu. File original baru diminta browser saat tombol download ditekan.
- Alamat bisa dibagikan dengan versi terpilih, contoh `/wallpaper/isabel-neon-rain?v=mobile`.
- Tanpa JavaScript, daftar link download per versi tampil sebagai gantinya.
- Nama file download: `TSC-Isabel-Neon-Rain-Mobile-1080x1920.png`. Nama file versi utama tidak berubah.
- Menambah versi atau kategori tidak perlu mengubah kode tampilan.

**Yang dicek build** (build berhenti dengan pesan jelas jika salah):

- id varian harus salah satu dari `variantTypes` di `site.config.json` (urutan di sana = urutan tampil).
- File harus ada di `content/originals/` dengan **huruf besar/kecil yang persis sama**. Ini penting karena Cloudflare membedakan `Mobile.PNG` dan `mobile.png`, sedangkan Windows/macOS tidak. Pesan galat menyebut nama file yang benar.
- Rasio file harus cocok dengan kategorinya (toleransi 2%). File 16:9 di kategori `mobile` ditolak.
- Isi file tidak boleh sama persis dengan versi lain dari wallpaper yang sama (mencegah satu gambar menjiplak banyak kategori).
- `width`/`height` di data bersifat opsional. Jika diisi dan tidak cocok dengan file sebenarnya, build berhenti. Jika kosong, ukuran dibaca dari file.
- Ukuran file di atas 25 MiB memunculkan peringatan (batas Cloudflare Pages).

### Alur dari HP Android (tanpa install apa pun)

1. Buka repository GitHub-mu di browser (Chrome, aktifkan "Situs desktop" jika menu upload tidak muncul).
2. Masuk ke folder `content/originals`, pilih **Add file, Upload files**, pilih gambar dari HP. Pilih **Create a new branch** (misalnya `wallpaper-baru`) lalu commit.
3. Pada branch yang sama, buka `content/wallpapers.json`, tekan ikon pensil, tambahkan blok entri, commit.
4. Cloudflare Pages otomatis membuat **Preview URL** untuk branch itu (lihat tab Deployments di dashboard Cloudflare). Buka di HP, cek halaman wallpaper dan tes tombol download.
5. Kalau sudah benar, buat Pull Request dan **Merge** ke branch utama. Situs produksi ter-update sendiri.

Kalau build gagal, buka log build di Cloudflare. Pesan kesalahan memakai bahasa Indonesia dan menyebut entri atau file yang bermasalah.

## 4. Mengganti gambar panel kaca di Home

Panel ini terpisah dari galeri, jadi mengganti gambarnya **tidak mengubah daftar wallpaper**.

1. Taruh gambar di folder `content/home-panel/` (PNG dengan latar transparan paling bagus, JPG/WebP juga bisa).
2. Buka `site.config.json` dan ubah bagian `homePanel`:

```json
"homePanel": {
  "image": "nama-file-kamu.png",
  "alt": "Deskripsi singkat gambar untuk pembaca layar",
  "caption": ""
}
```

3. Commit. Selesai. Proporsi gambar dipertahankan (`object-fit: contain`), tidak di-crop.
4. Kosongkan `"image"` untuk kembali ke placeholder bawaan. Jika nama file salah, build memberi peringatan dan memakai placeholder.

Catatan: gambar panel diproses menjadi salinan WebP (maks. lebar 1400 px) agar halaman Home ringan. Itu hanya untuk tampilan, bukan file download.

## 5. Deploy ke Cloudflare Pages (build otomatis lewat GitHub)

**Yang sudah selesai di proyek ini:** semua kode, `.node-version`, header Cloudflare (`_headers`), dan 404 khusus.

**Yang harus kamu lakukan:**

1. Buat akun GitHub dan repository baru, lalu upload isi folder proyek ini. (`node_modules`, `dist`, `.cache` sengaja tidak ikut, lihat `.gitignore`.)
2. Buat akun Cloudflare (gratis). Buka **Workers & Pages**, pilih **Create**, lalu **Pages**, dan hubungkan ke GitHub (**Connect to Git**). Pilih repository-nya. Tampilan menu Cloudflare bisa berubah, cari opsi yang sepadan.
3. Isi pengaturan build:
   - Framework preset: **None**
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Environment variable (opsional): `NODE_VERSION` = `20`
4. **Save and Deploy.** Setelah selesai kamu mendapat URL seperti `https://nama-project.pages.dev`.
5. **Isi `siteUrl`** di `site.config.json` dengan URL itu (contoh `"siteUrl": "https://nama-project.pages.dev"`), lalu commit. Ini mengaktifkan canonical, Open Graph, dan sitemap.
6. **Isi link TikTok/YouTube** di `site.config.json` (`"tiktok"`, `"youtube"`). Selama kosong, link-nya disembunyikan supaya tidak ada tombol mati.
7. **Hapus wallpaper SAMPLE** (3 entri di `wallpapers.json` beserta 10 file sampel di `content/originals/`, termasuk 7 file variasi contoh), lalu tambahkan wallpaper aslimu.

### Domain sendiri (nanti, opsional)

Di project Pages, buka **Custom domains**, **Set up a domain**, lalu ikuti petunjuk DNS Cloudflare. Setelah aktif, ubah `siteUrl` ke domain baru dan commit. Untuk path `/original/*`, biarkan fitur optimasi gambar Cloudflare (Polish, Mirage) mati agar file tidak diubah.

## 6. Menjalankan di komputer (opsional)

1. Pasang Node.js 18.17 atau lebih baru (https://nodejs.org, pilih LTS).
2. Di folder proyek:

```bash
npm install
npm run dev
```

3. Buka `http://localhost:8080`. Alamat untuk HP di Wi-Fi yang sama ikut tercetak di terminal, jadi kamu bisa melihat hasilnya di HP.
4. Build produksi saja: `npm run build` (hasil di `dist/`).
5. Setelah menambah wallpaper, hentikan (Ctrl+C) dan jalankan `npm run dev` lagi.

## 7. Tema warna, tipografi, glow, dan navigasi

### Warna (dark editorial)

Semua warna ada di blok `:root` di bagian atas `src/static/css/style.css`. Ubah di sana, seluruh situs ikut berubah.

| Variabel | Nilai | Dipakai untuk |
|---|---|---|
| `--bg` | `#080709` | latar utama |
| `--bg-2` | `#100D10` | latar sekunder: navigasi, kolom pencarian, latar di belakang gambar |
| `--panel` | `#171317` | kartu dan panel |
| `--line` | `#332328` | garis pemisah dan border |
| `--text` / `--muted` | `#E0D8D6` / `#82767A` | teks utama / teks sekunder |
| `--accent` | `#A83C2B` | merah marun: tombol penting, indikator tab aktif, garis |
| `--accent-dim` | `#6C3932` | merah redup: garis dekoratif, border saat hover, bilah di sisi blok |
| `--coral` | `#F0A08D` | judul penting (judul hero, halaman, dan wallpaper), fokus keyboard, link |

Merah dipakai **hanya** pada garis, tombol utama (Download Wallpaper, Explore Wallpapers), indikator tab aktif, border hover, dan bilah kiri blok. Merah tidak dipakai sebagai warna teks, karena kontrasnya terlalu rendah di latar gelap. Teks kecil memakai warna netral atau coral.

Turunan netral yang ditambahkan agar teks tetap terbaca: `--soft` (`#B9AFAD`, paragraf), `--meta` (`#968B8F`, metadata kecil di atas panel, karena `#82767A` hanya 4,2:1 di atas `#171317`), `--line-strong` (`#4A393F`, border input), `--accent-hover` (`#BF4A38`), dan `--on-accent` (`#FBF4F2`, teks di tombol marun).

### Tipografi

| Peran | Font | Catatan |
|---|---|---|
| Judul, nama merek, judul kartu | Bebas Neue | uppercase, letter-spacing 0,06 sampai 0,16 em |
| Isi, deskripsi | Barlow (300, 400, 500, 600) | bersih, 16px untuk isi |
| Label kecil, nomor koleksi, metadata, navigasi | Share Tech Mono | uppercase, letter-spacing lebar, minimal 0,64rem |

Font dimuat dari Google Fonts (`display=swap`) lewat satu tag di `src/templates/layout.html`. Jika gagal dimuat, situs memakai Oswald/Arial Narrow lalu font sistem. Untuk menyajikan font sendiri (tanpa Google), unduh file `.woff2`-nya, taruh di `src/static/fonts/`, tambahkan `@font-face` di CSS, dan hapus tag Google Fonts.

### Glow teks

Glow hanya aktif pada elemen yang diberi class khusus, dan sangat halus (satu lapis merah marun). Paragraf, navigasi, metadata, dan deskripsi tidak diberi glow.

| Class | Dipakai untuk |
|---|---|
| `.text-glow-primary` | judul brand utama di hero |
| `.text-glow-accent` | judul halaman, judul bagian, judul wallpaper |
| `.text-glow-hover` | label interaktif ("View all wallpapers"), glow hanya saat hover/fokus |

```css
--glow-main: 168 60 43;            /* warna glow (RGB) */
--glow-soft: 240 160 141;
--glow-primary-intensity: 0.7;     /* 0 = mati, 1 = penuh */
--glow-accent-intensity: 0.6;
```

Tidak ada animasi yang berjalan terus-menerus. Transisi (hover, tab navigasi) hanya 0,2 sampai 0,25 detik dan dimatikan jika pengguna memilih "kurangi gerakan".

### Navigasi responsif

Hanya ada **satu** komponen `<nav>` (di `src/templates/layout.html`, isinya dibuat oleh `navHtml()` di `scripts/build.mjs`). CSS-nya memilih tata letak berdasarkan lebar dan orientasi layar, bukan jenis perangkat:

| Kondisi layar | Tata letak |
|---|---|
| lebar di bawah 768px, portrait (mobile) | bottom bar tetap di bawah: ikon + label ringkas |
| lebar 768px ke atas (tablet, desktop) | sidebar vertikal kiri, lebar 88px |
| landscape dengan tinggi 500px ke bawah (HP miring) | sidebar kiri lebih ramping (72px), header tidak ikut menempel supaya ruang baca tidak terpotong |

Detail yang sudah diatur:

- Konten, footer, dan tombol unduh tidak tertutup: `body` diberi padding sebesar ruang navigasi, dan `scroll-padding-bottom` mencegah elemen yang sedang fokus bersembunyi di balik bottom bar.
- Safe area (notch, home indicator) dihitung lewat `env(safe-area-inset-*)` yang dikumpulkan di variabel `--safe-top/right/bottom/left`.
- Tab aktif ditandai dengan warna, latar pil di belakang ikon, **dan** garis indikator, jadi tidak bergantung pada warna saja. Transisinya 0,2 detik dan mati otomatis pada mode "kurangi gerakan".
- Keyboard: urutan Tab adalah skip link, merek, lalu Home, Gallery, About. Fokus terlihat jelas (cincin 2px coral). Halaman aktif memakai `aria-current="page"`.
- Ukuran dan breakpoint ada di variabel `--nav-h` (tinggi bottom bar), `--rail-w` (lebar sidebar), dan aturan `@media` di bagian "HEADER + NAVIGASI" pada CSS.
- Menambah halaman baru: tambahkan satu baris di `navHtml()` (kunci, label, alamat) dan satu ikon di `NAV_ICONS`. Bottom bar membagi lebar otomatis, tetapi sebaiknya maksimal 5 item agar label tetap terbaca.

## 8. Memastikan download benar-benar original

Lapisan perlindungan yang sudah ada:

- Tombol Download Wallpaper hanya ada di halaman detail wallpaper. Ia mengarah langsung ke `/original/<nama>.png`, salinan byte-per-byte dari `content/originals/`. Preview WebP tidak pernah dipakai untuk download.
- Saat build, setiap salinan diverifikasi dengan SHA-256. Build **gagal** jika ada satu byte pun yang beda.
- Sebelum mengunduh, browser memeriksa (HEAD, tanpa mengunduh isi file) bahwa file ada dan ukurannya sesuai katalog. Jika file hilang atau ukurannya beda, muncul pesan galat yang jelas dan **tidak ada preview yang diam-diam menggantikannya**.
- File original tidak diminta browser kecuali pengguna menekan tombol download.
- `Content-Disposition: attachment` di folder `/original/` (lihat `src/static/_headers`).
- Semua file original disajikan dari domain yang sama dengan situs, jadi atribut `download` dan nama file rapi bekerja tanpa pengaturan CORS. Jika suatu saat file dipindah ke CDN/domain lain, atribut `download` diabaikan browser dan server file harus mengirim header `Content-Disposition: attachment`.
- Saat tombol ditekan, tombol sementara tidak bisa diklik ganda (status sibuk) sampai pemeriksaan selesai. Jika gagal, muncul pesan merah di layar.

### Perlindungan gambar wallpaper (apa yang dilakukan dan batasnya)

Yang diterapkan, hanya pada area gambar wallpaper (kartu, pratinjau detail, panel Home), bukan pada seluruh situs:

- menu klik-kanan/long-press pada gambar dinonaktifkan (`contextmenu` dicegah di area gambar),
- gambar tidak bisa diseret (`draggable="false"`, `dragstart` dicegah),
- gambar tidak bisa diseleksi (`user-select: none`), dan callout long-press iOS dimatikan (`-webkit-touch-callout: none`),
- gambar tidak menerima sentuhan langsung (`pointer-events: none`), jadi long-press jatuh ke pembungkusnya,
- tombol Download Wallpaper, navigasi, teks, dan menu klik-kanan di luar gambar tetap normal.

Kode ada di bagian "PERLINDUNGAN GAMBAR WALLPAPER" pada CSS dan di `src/static/js/app.js`.

**Batasnya:** ini hanya menghambat cara menyimpan tertentu. Screenshot, developer tools, dan membuka alamat file langsung tetap bisa dilakukan. Preview dan file original adalah file publik di internet, dan file original harus bisa diunduh agar tombol download bekerja. Jangan menganggap gambar tidak mungkin disalin.


Cara memeriksa sendiri:

- **Di HP/browser (paling mudah):** buka halaman wallpaper, pilih versinya, buka **Verify your download**, lalu pilih file hasil download versi itu. Browser menghitung SHA-256 di perangkatmu (tidak ada yang diunggah) dan membandingkannya dengan original. Butuh halaman `https` atau `localhost`.
- **Di komputer, build lokal:** `npm run verify`. Memeriksa SEMUA file original (versi utama dan variasi): isi identik, checksum, ukuran, dimensi, nama file persis (huruf besar/kecil), rasio sesuai kategori, tidak ada duplikat antar versi, preview tersedia, dan tidak ada file di atas 25 MiB.
- **Di komputer, situs yang sudah online:** `npm run verify -- https://nama-project.pages.dev`. Mengunduh tiap original (termasuk variasi) dari situs, lalu membandingkan checksum, ukuran, dan dimensi.

Catatan: aplikasi chat/galeri tertentu bisa mengompresi gambar saat dibagikan. Verifikasi file yang diunduh langsung dari situs.

## 9. Kredit dan non-afiliasi

Semua teks ada di `site.config.json`, jadi mudah diperbarui:

- `ipNotice`: kepemilikan The Spike Cross dan karakternya (menyebut SUNCYAN sebagai salah satu pemegang hak).
- `disclaimer`: pernyataan proyek fan independen, tidak berafiliasi atau didukung SUNCYAN.
- `artworkTypes` dan field `artwork` per wallpaper: membedakan karakter resmi dari artwork AI, fan art, atau karya orisinal.
- `credits`: daftar kredit di halaman About. Field `credit` per wallpaper menambah baris kredit khusus di halaman wallpaper.

Tidak ada lisensi, izin, atau dukungan yang dikarang. **Tolong periksa sendiri bahwa kalimatnya sesuai** dengan ketentuan pemegang hak The Spike Cross sebelum publish.

## 10. Troubleshooting

| Masalah | Penyebab dan solusi |
|---|---|
| Build gagal: "file ... tidak ditemukan" | Nama di `file` harus sama persis dengan file di `content/originals/`, termasuk huruf besar/kecil (server Cloudflare membedakan `Isabel.PNG` dan `isabel.png`) |
| Build gagal: "bukan JSON yang valid" | Biasanya kurang/lebih koma atau tanda kutip di `wallpapers.json`. Pesan menyebut baris dan kolomnya |
| Halaman wallpaper 404 setelah deploy | Pastikan Build output directory = `dist` dan build berhasil. Entri harus ada di `wallpapers.json` |
| Gambar tidak muncul di situs | Tekan refresh paksa. Cek di log build bahwa wallpaper terdaftar. Cek huruf besar/kecil nama file |
| Download gagal dengan pesan merah | File original tidak ada atau ukurannya tidak cocok di server. Cek deploy terakhir berhasil, lalu jalankan `npm run verify -- URL` |
| Varian tidak muncul di halaman detail | Pastikan versi itu tercantum di `variants` dan build berhasil. Versi yang tidak tercantum memang tidak ditampilkan |
| Build gagal: "rasio file ... tidak sesuai kategori" | File ditaruh di kategori yang salah, atau rasionya tidak mendekati target (toleransi 2%) |
| Build gagal: "huruf besar/kecilnya berbeda" | Samakan nama di `wallpapers.json` dengan nama file persis |
| Cloudflare menolak file | Batas Cloudflare Pages: **25 MiB per file**. Lihat bagian 11 |
| Pratinjau link tidak muncul di media sosial | `siteUrl` belum diisi, atau cache media sosial masih lama. Isi `siteUrl`, deploy ulang, lalu uji ulang link |
| Font terlihat berbeda | Font dimuat dari Google Fonts. Jika diblokir, situs memakai font sistem |
| `npm install` gagal di komputer | Pastikan Node.js 18.17 atau lebih baru |

## 11. Batasan hosting statis

- Situs statis **tidak punya dashboard upload yang aman, akun pengguna, atau tagihan langganan**. Konten dikelola lewat GitHub (upload file + edit JSON). Dashboard upload membutuhkan backend dan autentikasi, dan tidak ditambahkan karena belum ada kebutuhan konkret.
- Cloudflare Pages membatasi **25 MiB per file** dan 20.000 file per situs. Original yang lebih besar perlu disimpan di tempat lain (misalnya Cloudflare R2). Untuk file di domain lain, atribut `download` diabaikan browser, jadi header `Content-Disposition` harus diatur oleh server penyimpanannya.
- Navigasi (bottom bar/sidebar) dirancang untuk sampai sekitar lima item. Jika halaman bertambah jauh lebih banyak, perlu menu tambahan (misalnya tombol "More").
- Google Fonts adalah satu-satunya dependensi eksternal. Untuk menghilangkannya, unduh file font dan sajikan sendiri dari `src/static/`.
- Pencarian dan filter berjalan di browser dari halaman yang sudah dimuat. Ini cepat untuk ratusan wallpaper. Untuk ribuan, perlu strategi lain.
